///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"
#include <GLFW/glfw3.h>

class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);

    // Destructor
    ~ViewManager();

    // Mouse position callback for mouse interaction with the 3D scene
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    // Mouse scroll callback for adjusting speed
    static void Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

    // Create the initial OpenGL display window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepare the 3D scene for rendering
    void PrepareSceneView();

private:
    // Process keyboard events for interaction with the 3D scene
    void ProcessKeyboardEvents();

    ShaderManager* m_pShaderManager; // Pointer to the shader manager
    GLFWwindow* m_pWindow;           // Active OpenGL display window
};