///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
    // Constructor
    SceneManager(ShaderManager* pShaderManager);

    // Destructor
    ~SceneManager();

    // Structure for texture information
    struct TEXTURE_INFO
    {
        std::string tag;   // Texture identifier
        uint32_t ID;       // Texture ID
    };

    // Structure for material properties
    struct OBJECT_MATERIAL
    {
        glm::vec3 ambientColor;     // Ambient color of the material
        float ambientStrength;      // Strength of ambient light for the material
        glm::vec3 diffuseColor;     // Diffuse color of the material
        glm::vec3 specularColor;    // Specular color of the material
        float shininess;            // Shininess factor for specular reflection
        std::string tag;            // Unique tag to identify the material
    };

private:
    // Shader manager pointer
    ShaderManager* m_pShaderManager;

    // Shape meshes pointer
    ShapeMeshes* m_basicMeshes;

    // Number of loaded textures
    int m_loadedTextures;

    // Array of texture info
    TEXTURE_INFO m_textureIDs[16];

    // List of defined materials
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // Load texture images and convert to OpenGL texture data
    bool CreateGLTexture(const char* filename, std::string tag);

    // Bind loaded OpenGL textures to slots in memory
    void BindGLTextures();

    // Free the loaded OpenGL textures
    void DestroyGLTextures();

    // Find a loaded texture by tag
    int FindTextureID(std::string tag);
    int FindTextureSlot(std::string tag);

    // Find a defined material by tag
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Set transformation values into the transform buffer
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    // Set color values into the shader
    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    // Set texture data into the shader
    void SetShaderTexture(
        std::string textureTag);

    // Set UV scale for texture mapping
    void SetTextureUVScale(
        float u, float v);

    // Set material properties into the shader
    void SetShaderMaterial(
        std::string materialTag);

public:
    // Methods for students to customize
    void PrepareScene();
    void RenderScene();

    // Pre-set light sources for the 3D scene
    void SetupSceneLights();

    // Pre-define the object materials for lighting
    void DefineObjectMaterials();
};