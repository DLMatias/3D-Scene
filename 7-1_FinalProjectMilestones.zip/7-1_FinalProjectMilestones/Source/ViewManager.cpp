///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

namespace
{
    const int WINDOW_WIDTH = 1000;  // Width of the display window
    const int WINDOW_HEIGHT = 800; // Height of the display window

    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr; // Camera object for interacting with the 3D scene

    float gLastX = WINDOW_WIDTH / 2.0f; // Last mouse x position
    float gLastY = WINDOW_HEIGHT / 2.0f; // Last mouse y position
    bool gFirstMouse = true;            // First mouse event flag

    float gDeltaTime = 0.0f;            // Time between frames
    float gLastFrame = 0.0f;            // Time of last frame

    bool bOrthographicProjection = false; // Toggle for projection type
}

ViewManager::ViewManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager), m_pWindow(nullptr)
{
    g_pCamera = new Camera();
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.5f, -1.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f;
    g_pCamera->MovementSpeed = 20.0f;
}

ViewManager::~ViewManager()
{
    delete g_pCamera;
    g_pCamera = nullptr;
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (!window)
    {
        std::cout << "Failed to create GLFW window\n";
        glfwTerminate();
        return nullptr;
    }
    glfwMakeContextCurrent(window);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Set callback functions for mouse movement and scroll
    glfwSetCursorPosCallback(window, Mouse_Position_Callback);
    glfwSetScrollCallback(window, Scroll_Callback);

    // Enable blending for transparency
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos - gLastX);
    float yOffset = static_cast<float>(gLastY - yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

void ViewManager::Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
    g_pCamera->ProcessMouseScroll(static_cast<float>(yOffset));
}

void ViewManager::ProcessKeyboardEvents()
{
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
    }
}

void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // Get the current time for delta-time calculations
    float currentFrame = glfwGetTime();
    gDeltaTime = static_cast<float>(currentFrame - gLastFrame);
    gLastFrame = currentFrame;

    // Process keyboard events for movement
    ProcessKeyboardEvents();

    // Configure the view matrix based on the projection mode
    if (bOrthographicProjection)
    {
        // Set the camera directly in front of the scene, looking straight at it
        g_pCamera->Position = glm::vec3(0.0f, 5.0f, 10.0f); // Camera positioned in front of the scene
        g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);    // Look directly into the scene
        g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);        // Up vector remains vertical
    }

    // Get the view matrix
    view = g_pCamera->GetViewMatrix();

    // Toggle between perspective and orthographic modes
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
    {
        bOrthographicProjection = false;
    }
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
    {
        bOrthographicProjection = true;
    }

    // Configure the projection matrix
    if (bOrthographicProjection)
    {
        // Orthographic projection parameters
        projection = glm::ortho(-10.0f, 10.0f, -10.0f, 10.0f, 0.1f, 20.0f);
    }
    else
    {
        // Perspective projection parameters
        projection = glm::perspective(glm::radians(g_pCamera->Zoom), static_cast<float>(WINDOW_WIDTH) / static_cast<float>(WINDOW_HEIGHT), 0.1f, 100.0f);
    }

    // Update the shader with the new view and projection matrices
    m_pShaderManager->setMat4Value(g_ViewName, view);
    m_pShaderManager->setMat4Value(g_ProjectionName, projection);
    m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
}